# InstaFocus

Android accessibility-based focus overlay for Instagram.

## GitHub Actions build

The repository includes `.github/workflows/android.yml`.

The workflow supports both of these repository layouts:

### Recommended
```text
.github/workflows/android.yml
app/
build.gradle.kts
gradle.properties
settings.gradle.kts
```

### Also supported
```text
SomeFolder/
  app/
  build.gradle.kts
  settings.gradle.kts
.github/workflows/android.yml
```

The workflow automatically locates `settings.gradle.kts`, verifies the Android project, builds it with Gradle 8.7, and uploads the debug APK as `InstaFocus-debug-apk`.

### Important GitHub upload instruction

Do **not** upload the ZIP file itself as the project. Extract this ZIP first and upload the files/folders inside it to the repository. The `.github` folder must be present in the repository so GitHub Actions can see the workflow.

After pushing the files:

1. Open **Actions**.
2. Select **Build InstaFocus APK**.
3. Select **Run workflow** if using manual dispatch.
4. After a successful build, open the run and download the **InstaFocus-debug-apk** artifact.

## App behavior

The app uses an Android Accessibility Service to place touch-consuming overlays over selected Instagram UI areas. It does not modify Instagram's files.

The implementation is heuristic because Instagram's UI/accessibility labels can change between app versions.
